/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esbagno;

/**
 *
 * @author Tomma
 */
public class runnable1 implements Runnable {
    
    public void run(){
        bagno p1= new bagno();
        p1.stampaUomo();
    }
    
    
    
}
